// Copyright 2024-2026 Golem Cloud
//
// Licensed under the Golem Source License v1.1 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://license.golem.cloud/LICENSE
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::benchmarks::{
    cleanup_account, cleanup_env_and_app, delete_workers, invoke_and_await_agent,
};
use async_trait::async_trait;
use futures_concurrency::future::Join;
use golem_common::model::AgentId;
use golem_common::model::agent::ParsedAgentKey;
use golem_common::model::component::ComponentDto;
use golem_common::model::environment::EnvironmentId;
use golem_common::{agent_id, data_value};
use golem_test_framework::benchmark::{
    Benchmark, BenchmarkRecorder, BenchmarkResultValue, RunConfig,
};
use golem_test_framework::config::benchmark::TestMode;
use golem_test_framework::config::dsl_impl::TestUserContext;
use golem_test_framework::config::{BenchmarkTestDependencies, TestDependencies};
use golem_test_framework::dsl::{TestDsl, TestDslExtended};
use indoc::indoc;
use std::time::Duration;
use tracing::{Instrument, Level};

pub struct ColdStartUnknownSmall {
    config: RunConfig,
}
pub struct ColdStartUnknownMedium {
    config: RunConfig,
}

#[async_trait]
impl Benchmark for ColdStartUnknownSmall {
    type BenchmarkContext = ColdStartUnknownBenchmark;
    type IterationContext = IterationContext;

    fn name() -> &'static str {
        "cold-start-unknown-small"
    }

    fn description() -> &'static str {
        indoc! {
            "
            Benchmarks the first-time invocation of a component that have never been instantiated before.
            This variant uses a relatively small Rust agent component. The `size` parameter is the number of
            unique components, and `length` is the time in seconds _per component_ to wait for pre-compilation.
            "
        }
    }

    async fn create_benchmark_context(
        mode: &TestMode,
        verbosity: Level,
        cluster_size: usize,
        disable_compilation_cache: bool,
        otlp: bool,
    ) -> BenchmarkResultValue<Self::BenchmarkContext> {
        Ok(ColdStartUnknownBenchmark::new(
            "benchmark_agent_rust_release",
            "RustBenchmarkAgent",
            mode,
            verbosity,
            cluster_size,
            disable_compilation_cache,
            otlp,
        )
        .await)
    }

    async fn cleanup(benchmark_context: Self::BenchmarkContext) -> BenchmarkResultValue {
        benchmark_context.cleanup().await;
        Ok(())
    }

    async fn create(_mode: &TestMode, config: RunConfig) -> BenchmarkResultValue<Self> {
        Ok(Self { config })
    }

    async fn setup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        _recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue<Self::IterationContext> {
        Ok(benchmark_context.setup_iteration(&self.config).await)
    }

    async fn warmup(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        _context: &Self::IterationContext,
    ) -> BenchmarkResultValue {
        benchmark_context.warmup(&self.config).await;
        Ok(())
    }

    async fn run(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        benchmark_context.run(context, recorder).await;
        Ok(())
    }

    async fn cleanup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        benchmark_context.cleanup_iteration(context, recorder).await;
        Ok(())
    }
}

#[async_trait]
impl Benchmark for ColdStartUnknownMedium {
    type BenchmarkContext = ColdStartUnknownBenchmark;
    type IterationContext = IterationContext;

    fn name() -> &'static str {
        "cold-start-unknown-medium"
    }

    fn description() -> &'static str {
        indoc! {
            "
                Benchmarks the first-time invocation of a component that have never been instantiated before.
                This variant uses a basic TypeScript agent component. The `size` parameter is the number of unique
                components, and `length` is the time in seconds _per component_ to wait for pre-compilation.
                "
        }
    }

    async fn create_benchmark_context(
        mode: &TestMode,
        verbosity: Level,
        cluster_size: usize,
        disable_compilation_cache: bool,
        otlp: bool,
    ) -> BenchmarkResultValue<Self::BenchmarkContext> {
        Ok(ColdStartUnknownBenchmark::new(
            "benchmark_agent_ts",
            "BenchmarkAgent",
            mode,
            verbosity,
            cluster_size,
            disable_compilation_cache,
            otlp,
        )
        .await)
    }

    async fn cleanup(benchmark_context: Self::BenchmarkContext) -> BenchmarkResultValue {
        benchmark_context.cleanup().await;
        Ok(())
    }

    async fn create(_mode: &TestMode, config: RunConfig) -> BenchmarkResultValue<Self> {
        Ok(Self { config })
    }

    async fn setup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        _recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue<Self::IterationContext> {
        Ok(benchmark_context.setup_iteration(&self.config).await)
    }

    async fn warmup(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        _context: &Self::IterationContext,
    ) -> BenchmarkResultValue {
        benchmark_context.warmup(&self.config).await;
        Ok(())
    }

    async fn run(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        benchmark_context.run(context, recorder).await;
        Ok(())
    }

    async fn cleanup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        benchmark_context.cleanup_iteration(context, recorder).await;
        Ok(())
    }
}

pub struct IterationContext {
    user: TestUserContext<BenchmarkTestDependencies>,
    agents: Vec<(ComponentDto, ParsedAgentKey)>,
    /// One env_id per size (cold_start creates one env per component).
    env_ids: Vec<EnvironmentId>,
}

pub struct ColdStartUnknownBenchmark {
    component_name: String,
    agent_type_name: String,
    deps: BenchmarkTestDependencies,
}

impl ColdStartUnknownBenchmark {
    pub async fn new(
        component_name: &str,
        agent_type_name: &str,
        mode: &TestMode,
        verbosity: Level,
        cluster_size: usize,
        disable_compilation_cache: bool,
        otlp: bool,
    ) -> Self {
        Self {
            component_name: component_name.to_string(),
            agent_type_name: agent_type_name.to_string(),
            deps: BenchmarkTestDependencies::new(
                mode,
                verbosity,
                cluster_size,
                disable_compilation_cache,
                otlp,
            )
            .await,
        }
    }

    pub async fn cleanup(&self) {
        self.deps.kill_all().await
    }

    pub async fn setup_iteration(&self, config: &RunConfig) -> IterationContext {
        let user = self.deps.user().await.unwrap();
        let mut agents = vec![];
        let mut env_ids = vec![];

        for _ in 0..config.size {
            // Agent types names are unique within one environment,
            // so make sure each component get its own env
            let (_, env) = user.app_and_env().await.unwrap();
            env_ids.push(env.id);

            let component = user
                .component(&env.id, &self.component_name)
                .unique()
                .store()
                .await
                .unwrap();

            let agent_id = agent_id!(&self.agent_type_name, "test");
            agents.push((component, agent_id));
        }

        IterationContext {
            user,
            agents,
            env_ids,
        }
    }

    pub async fn warmup(&self, config: &RunConfig) {
        if !config.disable_compilation_cache {
            let duration = Duration::from_secs(config.length as u64 * config.size as u64);
            async {
                tokio::time::sleep(duration).await;
            }
            .instrument(tracing::info_span!(
                "wait_compilation_cache",
                duration_secs = duration.as_secs()
            ))
            .await;
        }
    }

    pub async fn run(&self, iteration: &IterationContext, recorder: BenchmarkRecorder) {
        let result_futures = iteration
            .agents
            .iter()
            .map(move |(component, agent_id)| async move {
                let user_clone = iteration.user.clone();
                invoke_and_await_agent(
                    &user_clone,
                    component,
                    agent_id,
                    "echo",
                    data_value!("benchmark"),
                )
                .await
            })
            .collect::<Vec<_>>();

        let results = result_futures.join().await;
        for (idx, result) in results.iter().enumerate() {
            result.record(&recorder, "", idx.to_string().as_str());
        }
    }

    pub async fn cleanup_iteration(
        &self,
        iteration: IterationContext,
        recorder: BenchmarkRecorder,
    ) {
        let agent_ids: Vec<AgentId> = iteration
            .agents
            .iter()
            .filter_map(|(component, agent_id)| AgentId::from_agent_id(component.id, agent_id).ok())
            .collect();
        delete_workers(&iteration.user, &agent_ids, &recorder).await;
        // Clean up each env/app individually, then delete the account once.
        // This avoids the account being deleted on the first env cleanup and
        // causing subsequent cleanup calls to fail (since the user token would
        // be invalid after account deletion).
        for env_id in &iteration.env_ids {
            cleanup_env_and_app(&iteration.user, env_id, &recorder).await;
        }
        cleanup_account(&iteration.user, &recorder).await;
    }
}
