// Copyright 2024-2026 Golem Cloud
//
// Licensed under the Golem Source License v1.1 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://license.golem.cloud/LICENSE
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use crate::benchmarks::{cleanup_user_state, delete_workers, invoke_and_await_agent};
use async_trait::async_trait;
use futures_concurrency::future::Join;
use golem_common::model::AgentId;
use golem_common::model::agent::ParsedAgentKey;
use golem_common::model::component::{ComponentDto, ComponentId};
use golem_common::model::environment::EnvironmentId;
use golem_common::{agent_id, data_value};
use golem_test_framework::benchmark::{
    Benchmark, BenchmarkRecorder, BenchmarkResultValue, RunConfig,
};
use golem_test_framework::config::benchmark::TestMode;
use golem_test_framework::config::dsl_impl::TestUserContext;
use golem_test_framework::config::{BenchmarkTestDependencies, TestDependencies};
use golem_test_framework::dsl::{TestDsl, TestDslExtended};
use indoc::indoc;
use std::sync::Mutex;
use tracing::{Instrument, Level, info};

pub struct DurabilityOverhead {
    config: RunConfig,
}

pub struct DurabilityOverheadBenchmarkContext {
    deps: BenchmarkTestDependencies,
}

pub struct DurabilityOverheadIterationContext {
    user: TestUserContext<BenchmarkTestDependencies>,
    component: ComponentDto,
    durable_persistent_agent_ids: Vec<ParsedAgentKey>,
    ephemeral_agent_ids: Vec<ParsedAgentKey>,
    final_ephemeral_agent_ids: Mutex<Vec<AgentId>>,
    durable_persistent_commit_agent_ids: Vec<ParsedAgentKey>,
    env_id: EnvironmentId,
}

fn agent_ids_to_agent_ids(component_id: ComponentId, agent_ids: &[ParsedAgentKey]) -> Vec<AgentId> {
    agent_ids
        .iter()
        .filter_map(|agent_id| AgentId::from_agent_id(component_id, agent_id).ok())
        .collect()
}

#[async_trait]
impl Benchmark for DurabilityOverhead {
    type BenchmarkContext = DurabilityOverheadBenchmarkContext;
    type IterationContext = DurabilityOverheadIterationContext;

    fn name() -> &'static str {
        "durability-overhead"
    }

    fn description() -> &'static str {
        indoc! {
            "Invokes oplog-heavy functions in parallel on `size` number of workers,
            using ephemeral and durable components. There's also a durable variant where after
            each operation we force an oplog commit. The invoked function gets the `length`
            parameter to control the length of its inner loop.
            The benchmark can be used to compare the overhead caused by persistence (using a low
            `size`) and also the effect of heavy persistence load caused by parallel running workers
            (using high `size`).
            "
        }
    }

    async fn create_benchmark_context(
        mode: &TestMode,
        verbosity: Level,
        cluster_size: usize,
        disable_compilation_cache: bool,
        otlp: bool,
    ) -> BenchmarkResultValue<Self::BenchmarkContext> {
        Ok(DurabilityOverheadBenchmarkContext {
            deps: BenchmarkTestDependencies::new(
                mode,
                verbosity,
                cluster_size,
                disable_compilation_cache,
                otlp,
            )
            .await,
        })
    }

    async fn cleanup(benchmark_context: Self::BenchmarkContext) -> BenchmarkResultValue {
        benchmark_context.deps.kill_all().await;
        Ok(())
    }

    async fn create(_mode: &TestMode, config: RunConfig) -> BenchmarkResultValue<Self> {
        Ok(Self { config })
    }

    async fn setup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        _recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue<Self::IterationContext> {
        let user = benchmark_context.deps.user().await.unwrap();
        let (_, env) = user.app_and_env().await.unwrap();

        let mut durable_persistent_agent_ids = vec![];
        let mut ephemeral_agent_ids = vec![];
        let mut durable_persistent_commit_agent_ids = vec![];

        info!("Registering component");
        let durable_component = user
            .component(&env.id, "benchmark_agent_rust_release")
            .name("benchmark:agent-rust")
            .store()
            .await
            .unwrap();

        for n in 0..self.config.size {
            durable_persistent_agent_ids.push(agent_id!(
                "RustBenchmarkAgent",
                format!("test-{n}-persistent")
            ));
            ephemeral_agent_ids.push(agent_id!(
                "RustEphemeralBenchmarkAgent",
                format!("test-{n}-ephemeral")
            ));
            durable_persistent_commit_agent_ids.push(agent_id!(
                "RustBenchmarkAgent",
                format!("test-{n}-persistent-commit")
            ));
        }

        Ok(DurabilityOverheadIterationContext {
            user,
            component: durable_component,
            durable_persistent_agent_ids,
            ephemeral_agent_ids,
            final_ephemeral_agent_ids: Mutex::new(Vec::new()),
            durable_persistent_commit_agent_ids,
            env_id: env.id,
        })
    }

    async fn warmup(
        &self,
        _benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
    ) -> BenchmarkResultValue {
        async fn warmup_group(
            user: &TestUserContext<BenchmarkTestDependencies>,
            component: &ComponentDto,
            ids: &[ParsedAgentKey],
        ) {
            let result_futures = ids
                .iter()
                .map(move |agent_id| async move {
                    let user_clone = user.clone();
                    invoke_and_await_agent(
                        &user_clone,
                        component,
                        agent_id,
                        "echo",
                        data_value!("test"),
                    )
                    .await
                })
                .collect::<Vec<_>>();
            let _ = result_futures.join().await;
        }

        warmup_group(
            &context.user,
            &context.component,
            &context.durable_persistent_agent_ids,
        )
        .instrument(tracing::info_span!("warmup_durable_persistent"))
        .await;
        Ok(())
    }

    async fn run(
        &self,
        _benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        let length = self.config.length as u32;

        async {
            let result_futures = context
                .durable_persistent_agent_ids
                .iter()
                .map(move |agent_id| async move {
                    let user_clone = context.user.clone();
                    invoke_and_await_agent(
                        &user_clone,
                        &context.component,
                        agent_id,
                        "oplog_heavy",
                        data_value!(length, false),
                    )
                    .await
                })
                .collect::<Vec<_>>();
            let results = result_futures.join().await;
            for (idx, result) in results.iter().enumerate() {
                result.record(&recorder, "durable-persistent-", idx.to_string().as_str());
            }
        }
        .instrument(tracing::info_span!("measure_durable_persistent"))
        .await;

        async {
            let result_futures = context
                .ephemeral_agent_ids
                .iter()
                .map(move |agent_id| async move {
                    let user_clone = context.user.clone();
                    invoke_and_await_agent(
                        &user_clone,
                        &context.component,
                        agent_id,
                        "oplog_heavy",
                        data_value!(length, false),
                    )
                    .await
                })
                .collect::<Vec<_>>();
            let results = result_futures.join().await;
            *context.final_ephemeral_agent_ids.lock().unwrap() = results
                .iter()
                .map(|result| {
                    result
                        .agent_id
                        .clone()
                        .expect("agent invocation must return its final agent ID")
                })
                .collect();
            for (idx, result) in results.iter().enumerate() {
                result.record(&recorder, "ephemeral-", idx.to_string().as_str());
            }
        }
        .instrument(tracing::info_span!("measure_ephemeral"))
        .await;

        async {
            let result_futures = context
                .durable_persistent_commit_agent_ids
                .iter()
                .map(move |agent_id| async move {
                    let user_clone = context.user.clone();
                    invoke_and_await_agent(
                        &user_clone,
                        &context.component,
                        agent_id,
                        "oplog_heavy",
                        data_value!(length, true),
                    )
                    .await
                })
                .collect::<Vec<_>>();
            let results = result_futures.join().await;
            for (idx, result) in results.iter().enumerate() {
                result.record(
                    &recorder,
                    "durable-persistent-commit-",
                    idx.to_string().as_str(),
                );
            }
        }
        .instrument(tracing::info_span!("measure_durable_persistent_commit"))
        .await;
        Ok(())
    }

    async fn cleanup_iteration(
        &self,
        _benchmark_context: &Self::BenchmarkContext,
        context: Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue {
        delete_workers(
            &context.user,
            &agent_ids_to_agent_ids(context.component.id, &context.durable_persistent_agent_ids),
            &recorder,
        )
        .await;
        delete_workers(
            &context.user,
            &context.final_ephemeral_agent_ids.into_inner().unwrap(),
            &recorder,
        )
        .await;
        delete_workers(
            &context.user,
            &agent_ids_to_agent_ids(
                context.component.id,
                &context.durable_persistent_commit_agent_ids,
            ),
            &recorder,
        )
        .await;
        cleanup_user_state(&context.user, &context.env_id, &recorder).await;
        Ok(())
    }
}
