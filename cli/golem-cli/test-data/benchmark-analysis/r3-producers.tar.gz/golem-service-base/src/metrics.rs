// Copyright 2024-2026 Golem Cloud
//
// Licensed under the Golem Source License v1.1 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://license.golem.cloud/LICENSE
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use lazy_static::lazy_static;
use prometheus::*;

lazy_static! {
    pub static ref VERSION_INFO: IntCounterVec =
        register_int_counter_vec!("version_info", "Version info of the server", &["version"])
            .unwrap();
}

pub mod storage {
    use lazy_static::lazy_static;
    use prometheus::*;

    pub const STORAGE_TYPE_COMPILATION_CACHE: &str = "compilation_cache";

    lazy_static! {
        pub static ref LOGICAL_OPERATIONS_TOTAL: IntCounterVec = register_int_counter_vec!(
            "golem_storage_logical_operations_total",
            "Storage API calls, including failed calls, before backend retries",
            &["kind", "operation", "service", "api", "entity"]
        )
        .unwrap();
        pub static ref STORAGE_BYTES_WRITTEN_TOTAL: CounterVec = register_counter_vec!(
            "golem_storage_bytes_written_total",
            "Total bytes written to storage, by storage type, account and environment",
            &["storage_type", "account_id", "environment_id"]
        )
        .unwrap();
        pub static ref STORAGE_OBJECTS_WRITTEN_TOTAL: CounterVec = register_counter_vec!(
            "golem_storage_objects_written_total",
            "Total objects written to storage, by storage type, account and environment",
            &["storage_type", "account_id", "environment_id"]
        )
        .unwrap();
        pub static ref STORAGE_OBJECTS_DELETED_TOTAL: CounterVec = register_counter_vec!(
            "golem_storage_objects_deleted_total",
            "Total objects deleted from storage, by storage type, account and environment",
            &["storage_type", "account_id", "environment_id"]
        )
        .unwrap();
        pub static ref COMPILATION_CACHE_BYTES_WRITTEN_TOTAL: CounterVec = register_counter_vec!(
            "golem_compilation_cache_bytes_written_total",
            "Total bytes written to the compiled component cache, by environment",
            &["storage_type", "environment_id"]
        )
        .unwrap();
        pub static ref COMPILATION_CACHE_OBJECTS_WRITTEN_TOTAL: CounterVec = register_counter_vec!(
            "golem_compilation_cache_objects_written_total",
            "Total objects written to the compiled component cache, by environment",
            &["storage_type", "environment_id"]
        )
        .unwrap();
    }

    pub fn record_logical_operation(
        kind: &'static str,
        operation: &'static str,
        service: &'static str,
        api: &'static str,
        entity: &'static str,
    ) {
        LOGICAL_OPERATIONS_TOTAL
            .with_label_values(&[kind, operation, service, api, entity])
            .inc();
    }

    pub fn record_storage_bytes_written(
        storage_type: &str,
        account_id: &str,
        environment_id: &str,
        bytes: u64,
    ) {
        STORAGE_BYTES_WRITTEN_TOTAL
            .with_label_values(&[storage_type, account_id, environment_id])
            .inc_by(bytes as f64);
    }

    pub fn record_storage_objects_written(
        storage_type: &str,
        account_id: &str,
        environment_id: &str,
        count: u64,
    ) {
        STORAGE_OBJECTS_WRITTEN_TOTAL
            .with_label_values(&[storage_type, account_id, environment_id])
            .inc_by(count as f64);
    }

    pub fn record_storage_objects_deleted(
        storage_type: &str,
        account_id: &str,
        environment_id: &str,
        count: u64,
    ) {
        STORAGE_OBJECTS_DELETED_TOTAL
            .with_label_values(&[storage_type, account_id, environment_id])
            .inc_by(count as f64);
    }

    pub fn record_compilation_cache_bytes_written(environment_id: &str, bytes: u64) {
        COMPILATION_CACHE_BYTES_WRITTEN_TOTAL
            .with_label_values(&[STORAGE_TYPE_COMPILATION_CACHE, environment_id])
            .inc_by(bytes as f64);
    }

    pub fn record_compilation_cache_objects_written(environment_id: &str, count: u64) {
        COMPILATION_CACHE_OBJECTS_WRITTEN_TOTAL
            .with_label_values(&[STORAGE_TYPE_COMPILATION_CACHE, environment_id])
            .inc_by(count as f64);
    }
}

pub mod grpc {
    //! Metrics for internal service-to-service gRPC calls made via `GrpcClient`.

    use std::time::Duration;

    use lazy_static::lazy_static;
    use prometheus::*;

    lazy_static! {
        static ref INTERNAL_GRPC_SUCCESS_SECONDS: HistogramVec = register_histogram_vec!(
            "internal_grpc_success_seconds",
            "Duration of successful internal gRPC calls between Golem services",
            &["target", "op"],
            golem_common::metrics::DEFAULT_TIME_BUCKETS.to_vec()
        )
        .unwrap();
        static ref INTERNAL_GRPC_FAILURE_TOTAL: CounterVec = register_counter_vec!(
            "internal_grpc_failure_total",
            "Number of failed internal gRPC calls that were not retried or exhausted retries",
            &["target", "op", "status_code"]
        )
        .unwrap();
        static ref INTERNAL_GRPC_RETRY_TOTAL: CounterVec = register_counter_vec!(
            "internal_grpc_retry_total",
            "Number of internal gRPC call attempts retried due to a reconnectable error",
            &["target", "op"]
        )
        .unwrap();
    }

    pub fn record_internal_grpc_success(target: &str, op: &str, duration: Duration) {
        INTERNAL_GRPC_SUCCESS_SECONDS
            .with_label_values(&[target, op])
            .observe(duration.as_secs_f64());
    }

    pub fn record_internal_grpc_failure(target: &str, op: &str, status: &tonic::Status) {
        let status_code = format!("{:?}", status.code());
        INTERNAL_GRPC_FAILURE_TOTAL
            .with_label_values(&[target, op, &status_code])
            .inc();
    }

    pub fn record_internal_grpc_retry(target: &str, op: &str) {
        INTERNAL_GRPC_RETRY_TOTAL
            .with_label_values(&[target, op])
            .inc();
    }
}

pub mod tls {
    //! Metrics for the TLS material the services keep current from files.

    use std::time::SystemTime;

    use lazy_static::lazy_static;
    use prometheus::*;

    lazy_static! {
        pub static ref CERTIFICATE_NOT_AFTER_SECONDS: GaugeVec = register_gauge_vec!(
            "golem_tls_certificate_not_after_seconds",
            "Unix time at which the TLS certificate in use expires, by use",
            &["use"]
        )
        .unwrap();
        pub static ref RELOAD_FAILURES_TOTAL: IntCounterVec = register_int_counter_vec!(
            "golem_tls_certificate_reload_failures_total",
            "Changed TLS files that could not be used, by use",
            &["use"]
        )
        .unwrap();
    }

    pub fn record_certificate_not_after(use_name: &str, not_after: SystemTime) {
        let seconds = match not_after.duration_since(SystemTime::UNIX_EPOCH) {
            Ok(d) => d.as_secs_f64(),
            Err(e) => -e.duration().as_secs_f64(),
        };
        CERTIFICATE_NOT_AFTER_SECONDS
            .with_label_values(&[use_name])
            .set(seconds);
    }

    pub fn record_reload_failure(use_name: &str) {
        RELOAD_FAILURES_TOTAL.with_label_values(&[use_name]).inc();
    }
}
