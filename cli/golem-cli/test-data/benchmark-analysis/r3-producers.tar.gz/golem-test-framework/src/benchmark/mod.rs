// Copyright 2024-2026 Golem Cloud
//
// Licensed under the Golem Source License v1.1 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://license.golem.cloud/LICENSE
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

mod config;
mod results;
pub mod storage_metrics;
#[cfg(test)]
mod tests;

pub use config::{
    BenchmarkConfig, BenchmarkPartition, BenchmarkSuite, BenchmarkSuiteItem, ChaosAction,
    ChaosScenarioArg, DensityAction, DensityAgentModeArg, DensityPromiseRuntimeArg,
    DensityPromiseTopologyArg, DensityPromiseWaiterPresenceArg, DensityScenarioArg,
    DensityScheduleTargetPatternArg, DensityScheduleTargetResidencyArg, DensitySectionArg,
    DensitySharingArg, DensitySnapshottingArg, RunConfig,
};
pub use results::{
    BenchmarkArtifact, BenchmarkArtifacts, BenchmarkResult, BenchmarkRunResult, BenchmarkRunner,
    BenchmarkSource, BenchmarkSuiteResult, BenchmarkSuiteResultCollection, CeilingMeasurement,
    HARNESS_VERSION, MeasurementEnvironment, ResultKey, RunMetadata, benchmark_sockets_enabled,
};

use crate::config::benchmark::TestMode;
use async_trait::async_trait;
use futures::FutureExt;
use itertools::Itertools;
use std::collections::HashMap;
use std::fmt::Debug;
use std::future::Future;
use std::panic::AssertUnwindSafe;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::Duration;
use tracing::{Instrument, Level, info};

#[derive(Debug, Clone)]
pub struct BenchmarkRecorder {
    state: Arc<Mutex<BenchmarkRecorderState>>,
}

impl Default for BenchmarkRecorder {
    fn default() -> Self {
        Self::new()
    }
}

impl BenchmarkRecorder {
    pub fn new() -> Self {
        Self {
            state: Arc::new(Mutex::new(BenchmarkRecorderState::new())),
        }
    }

    pub fn count(&self, key: &ResultKey, value: u64) {
        self.state.lock().unwrap().count(key, value);
    }

    pub fn counts(&self) -> HashMap<ResultKey, Vec<u64>> {
        self.state.lock().unwrap().counts.clone()
    }

    pub fn duration(&self, key: &ResultKey, value: Duration) {
        self.state.lock().unwrap().duration(key, value);
    }

    pub fn durations(&self) -> HashMap<ResultKey, Vec<Duration>> {
        self.state.lock().unwrap().durations.clone()
    }

    /// Records one failed attempt belonging to the measurement `key`. Failures
    /// are aggregated into the benchmark result next to the durations, so a
    /// run that needed retries is visible in the report and in the results
    /// JSON instead of only in the logs.
    pub fn failure(&self, key: &ResultKey, message: impl Into<String>) {
        self.state.lock().unwrap().failure(key, message.into());
    }

    pub fn failures(&self) -> HashMap<ResultKey, Vec<String>> {
        self.state.lock().unwrap().failures.clone()
    }
}

#[derive(Debug)]
pub struct BenchmarkRecorderState {
    durations: HashMap<ResultKey, Vec<Duration>>,
    counts: HashMap<ResultKey, Vec<u64>>,
    failures: HashMap<ResultKey, Vec<String>>,
}

impl Default for BenchmarkRecorderState {
    fn default() -> Self {
        Self::new()
    }
}

impl BenchmarkRecorderState {
    pub fn new() -> Self {
        Self {
            durations: HashMap::new(),
            counts: HashMap::new(),
            failures: HashMap::new(),
        }
    }

    pub fn count(&mut self, key: &ResultKey, value: u64) {
        self.counts.entry(key.clone()).or_default().push(value);
    }

    pub fn duration(&mut self, key: &ResultKey, value: Duration) {
        self.durations.entry(key.clone()).or_default().push(value);
    }

    pub fn failure(&mut self, key: &ResultKey, message: String) {
        self.failures.entry(key.clone()).or_default().push(message);
    }
}

#[derive(Debug, Clone)]
pub struct BenchmarkError {
    pub phase: ResultKey,
    pub message: String,
}

impl BenchmarkError {
    pub fn new(phase: impl AsRef<str>, message: impl ToString) -> Self {
        Self {
            phase: ResultKey::primary(phase),
            message: message.to_string(),
        }
    }
}

impl std::fmt::Display for BenchmarkError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}: {}", self.phase, self.message)
    }
}

impl std::error::Error for BenchmarkError {}

pub type BenchmarkResultValue<T = ()> = Result<T, BenchmarkError>;

/// The default deadline of one measured iteration, for `--run-deadline-secs`.
pub const DEFAULT_RUN_DEADLINE_SECS: u64 = 600;

static RUN_DEADLINE: OnceLock<Duration> = OnceLock::new();

/// Sets the deadline of the `run` phase of every iteration. The first call wins. A cloud
/// throughput iteration at size 250 and length 10000 takes more than the default: it makes
/// 25000 calls for each of six implementations, about 760s on Golem 1.5 on golem-dev.
pub fn set_run_deadline(deadline: Duration) {
    let _ = RUN_DEADLINE.set(deadline);
}

fn run_deadline() -> Duration {
    RUN_DEADLINE
        .get()
        .copied()
        .unwrap_or(Duration::from_secs(DEFAULT_RUN_DEADLINE_SECS))
}

async fn phase<T>(
    recorder: &BenchmarkRecorder,
    name: &str,
    deadline: Duration,
    future: impl Future<Output = BenchmarkResultValue<T>>,
) -> Option<T> {
    let result = match tokio::time::timeout(deadline, AssertUnwindSafe(future).catch_unwind()).await
    {
        Ok(Ok(result)) => result,
        Ok(Err(panic)) => Err(BenchmarkError::new(
            name,
            panic
                .downcast_ref::<String>()
                .map(String::as_str)
                .or_else(|| panic.downcast_ref::<&str>().copied())
                .unwrap_or("benchmark phase panicked"),
        )),
        Err(_) => Err(BenchmarkError::new(
            name,
            format!("deadline exceeded ({deadline:?})"),
        )),
    };
    match result {
        Ok(value) => Some(value),
        Err(error) => {
            recorder.failure(&error.phase, error.message);
            None
        }
    }
}

#[async_trait]
pub trait Benchmark: Send + Sync + Sized + 'static {
    type BenchmarkContext: Send + Sync + 'static;
    type IterationContext: Send + Sync + 'static;

    fn name() -> &'static str;
    fn description() -> &'static str;

    async fn create_benchmark_context(
        mode: &TestMode,
        verbosity: Level,
        cluster_size: usize,
        disable_compilation_cache: bool,
        otlp: bool,
    ) -> BenchmarkResultValue<Self::BenchmarkContext>;

    async fn cleanup(benchmark_context: Self::BenchmarkContext) -> BenchmarkResultValue;

    async fn create(mode: &TestMode, config: RunConfig) -> BenchmarkResultValue<Self>;

    async fn setup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue<Self::IterationContext>;

    async fn warmup(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
    ) -> BenchmarkResultValue;

    async fn run(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: &Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue;

    async fn cleanup_iteration(
        &self,
        benchmark_context: &Self::BenchmarkContext,
        context: Self::IterationContext,
        recorder: BenchmarkRecorder,
    ) -> BenchmarkResultValue;
}

#[async_trait]
pub trait BenchmarkApi {
    async fn run_benchmark_internal(
        mode: &TestMode,
        verbosity: Level,
        item: &BenchmarkSuiteItem,
        otlp: bool,
    ) -> BenchmarkResult;

    async fn run_benchmark(
        mode: &TestMode,
        verbosity: Level,
        item: &BenchmarkSuiteItem,
        primary_only: bool,
        retain_details: bool,
        retain_selected_zero_counts: bool,
        otlp: bool,
    ) -> BenchmarkResult {
        let mut results = Self::run_benchmark_internal(mode, verbosity, item, otlp).await;
        results.drop_zero_counts(retain_selected_zero_counts);
        if !retain_details {
            results.drop_details();
        }
        if primary_only {
            results.primary_only();
        }

        results
    }
}

async fn run_benchmark<B: Benchmark>(
    benchmark_context: &B::BenchmarkContext,
    mode: &TestMode,
    config: RunConfig,
    cluster_size: usize,
    iterations: usize,
    run_name: &str,
) -> BenchmarkRunResult {
    let span = tracing::info_span!(
        "benchmark",
        name = B::name(),
        cluster_size = cluster_size,
        size = config.size,
        length = config.length,
        run = run_name
    );
    let _enter = span.enter();
    info!("Starting benchmark iterations {}", B::name());

    let mut aggregated_results = BenchmarkRunResult::new(config.clone());
    let recorder = BenchmarkRecorder::new();
    let Some(benchmark) = phase(
        &recorder,
        "create",
        Duration::from_secs(300),
        B::create(mode, config.clone()),
    )
    .await
    else {
        aggregated_results.add(recorder);
        aggregated_results.skip_iterations(iterations, "create");
        return aggregated_results;
    };

    for iteration in 0..iterations {
        let span = tracing::info_span!(
            "benchmark",
            name = B::name(),
            run = run_name,
            iteration = iteration
        );
        let _enter = span.enter();
        info!("Starting iteration");

        let recorder = BenchmarkRecorder::new();
        if let Some(context) = phase(
            &recorder,
            "setup",
            Duration::from_secs(300),
            benchmark.setup_iteration(benchmark_context, recorder.clone()),
        )
        .await
        {
            if phase(
                &recorder,
                "warmup",
                Duration::from_secs(300),
                benchmark.warmup(benchmark_context, &context),
            )
            .await
            .is_some()
            {
                phase(
                    &recorder,
                    "run",
                    run_deadline(),
                    benchmark.run(benchmark_context, &context, recorder.clone()),
                )
                .await;
            }
            phase(
                &recorder,
                "cleanup-iteration",
                Duration::from_secs(120),
                benchmark.cleanup_iteration(benchmark_context, context, recorder.clone()),
            )
            .await;
        }
        aggregated_results.add_iteration(iteration, recorder);

        info!("Finished iteration");
    }

    aggregated_results
}

#[async_trait]
impl<B: Benchmark> BenchmarkApi for B {
    async fn run_benchmark_internal(
        mode: &TestMode,
        verbosity: Level,
        item: &BenchmarkSuiteItem,
        otlp: bool,
    ) -> BenchmarkResult {
        let span = tracing::info_span!("benchmark", name = B::name());
        let _enter = span.enter();
        info!("Initializing benchmark {}", B::name());

        let runs = item.runs(mode);
        let measurement_environment = MeasurementEnvironment::for_mode(mode);

        let runs_cnt = runs.len();
        let mut current_run = 0;

        let mut results = Vec::new();

        let groups = runs
            .iter()
            .chunk_by(|r| r.cluster_size)
            .into_iter()
            .map(|(cluster_size, group)| (cluster_size, group.collect::<Vec<_>>()))
            .collect::<Vec<_>>();

        for (cluster_size, runs) in groups {
            let span =
                tracing::info_span!("benchmark", name = B::name(), cluster_size = cluster_size);
            let _enter = span.enter();

            info!("Creating benchmark context");
            let recorder = BenchmarkRecorder::new();
            let context = phase(
                &recorder,
                "setup-context",
                Duration::from_secs(300),
                B::create_benchmark_context(
                    mode,
                    verbosity,
                    cluster_size,
                    item.disable_compilation_cache.unwrap_or_default(),
                    otlp,
                ),
            )
            .await;
            let Some(context) = context else {
                for config in runs {
                    let mut result = BenchmarkRunResult::new(config.clone());
                    result.add(recorder.clone());
                    result.skip_iterations(item.iterations, "setup-context");
                    results.push(result);
                }
                continue;
            };

            for config in runs {
                current_run += 1;
                let run_name = format!("{current_run}/{runs_cnt}");
                results.push(
                    run_benchmark::<B>(
                        &context,
                        mode,
                        config.clone(),
                        cluster_size,
                        item.iterations,
                        &run_name,
                    )
                    .instrument(span.clone())
                    .await,
                );
            }

            info!("Stopping benchmark context");
            phase(
                &recorder,
                "cleanup-context",
                Duration::from_secs(120),
                B::cleanup(context),
            )
            .await;
            if let Some(result) = results.last_mut() {
                result.add(recorder);
            }
        }

        BenchmarkResult {
            entry_version: item.version,
            iterations: item.iterations,
            series_key: measurement_environment.series_key(HARNESS_VERSION, item.version),
            measurement_environment,
            ceiling: None,
            name: if item.disable_compilation_cache.unwrap_or_default() {
                format!("{}-no-cache", B::name())
            } else {
                B::name().to_string()
            },
            description: B::description().to_string(),
            runs,
            results,
            run_id: None,
        }
    }
}
